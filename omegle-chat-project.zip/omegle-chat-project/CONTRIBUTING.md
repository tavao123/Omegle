# Guia de Contribuição - OmegleChat

Obrigado por considerar contribuir com o OmegleChat! Este documento fornece diretrizes para contribuições.

## Como Contribuir

### Reportando Bugs

1. Verifique se o bug já foi reportado nas [Issues](https://github.com/seu-usuario/omegle-chat/issues)
2. Se não encontrou, crie uma nova issue com:
   - Título descritivo
   - Passos para reproduzir
   - Comportamento esperado vs atual
   - Screenshots (se aplicável)
   - Informações do ambiente (OS, browser, versões)

### Sugerindo Melhorias

1. Abra uma issue com o label "enhancement"
2. Descreva claramente a melhoria proposta
3. Explique por que seria útil
4. Considere implementações alternativas

### Contribuindo com Código

#### Setup do Ambiente

1. Fork o repositório
2. Clone seu fork:
```bash
git clone https://github.com/seu-usuario/omegle-chat.git
cd omegle-chat
```

3. Instale dependências:
```bash
npm run install:all
```

4. Crie uma branch para sua feature:
```bash
git checkout -b feature/nome-da-feature
```

#### Padrões de Código

**Backend (Python)**:
- Siga PEP 8
- Use type hints quando possível
- Docstrings para funções públicas
- Máximo 88 caracteres por linha

```python
def create_chat_room(user1_id: str, user2_id: str) -> ChatRoom:
    """
    Cria uma nova sala de chat entre dois usuários.
    
    Args:
        user1_id: ID do primeiro usuário
        user2_id: ID do segundo usuário
        
    Returns:
        ChatRoom: Nova instância da sala de chat
    """
    room_id = str(uuid.uuid4())
    return ChatRoom(room_id, user1_id, user2_id)
```

**Frontend (JavaScript/React)**:
- Use ESLint e Prettier
- Componentes funcionais com hooks
- Props tipadas com PropTypes ou TypeScript
- Nomes descritivos para variáveis e funções

```javascript
const ChatMessage = ({ message, sender, timestamp }) => {
  const isFromStranger = sender === 'stranger';
  
  return (
    <div className={`message ${isFromStranger ? 'stranger' : 'you'}`}>
      <span className="message-text">{message}</span>
      <span className="message-time">{formatTime(timestamp)}</span>
    </div>
  );
};
```

#### Testes

- Escreva testes para novas funcionalidades
- Mantenha cobertura de testes acima de 80%
- Teste tanto casos de sucesso quanto de erro

**Backend**:
```python
def test_user_matching():
    """Testa se o sistema de matching funciona corretamente."""
    user1 = create_user()
    user2 = create_user()
    
    room_id, partner_id = find_match_for_user(user1.id)
    assert room_id is None  # Primeiro usuário deve aguardar
    
    room_id, partner_id = find_match_for_user(user2.id)
    assert room_id is not None  # Segundo usuário deve fazer match
    assert partner_id == user1.id
```

**Frontend**:
```javascript
test('should display message correctly', () => {
  const message = {
    text: 'Hello world',
    sender: 'stranger',
    timestamp: '2024-01-01T10:00:00Z'
  };
  
  render(<ChatMessage {...message} />);
  
  expect(screen.getByText('Hello world')).toBeInTheDocument();
  expect(screen.getByText('10:00')).toBeInTheDocument();
});
```

#### Commits

Use mensagens de commit descritivas seguindo o padrão:

```
tipo(escopo): descrição breve

Descrição mais detalhada se necessário.

Fixes #123
```

**Tipos**:
- `feat`: Nova funcionalidade
- `fix`: Correção de bug
- `docs`: Documentação
- `style`: Formatação, sem mudança de lógica
- `refactor`: Refatoração de código
- `test`: Adição ou correção de testes
- `chore`: Tarefas de manutenção

**Exemplos**:
```
feat(chat): adicionar suporte a emojis nas mensagens

fix(webrtc): corrigir conexão em redes NAT restritivas

docs(api): atualizar documentação dos eventos WebSocket
```

#### Pull Requests

1. Certifique-se que todos os testes passam
2. Atualize documentação se necessário
3. Adicione entrada no CHANGELOG.md
4. Crie PR com:
   - Título descritivo
   - Descrição detalhada das mudanças
   - Screenshots (se aplicável)
   - Referência a issues relacionadas

**Template de PR**:
```markdown
## Descrição
Breve descrição das mudanças realizadas.

## Tipo de Mudança
- [ ] Bug fix
- [ ] Nova funcionalidade
- [ ] Breaking change
- [ ] Documentação

## Como Testar
1. Passos para testar as mudanças
2. Casos de teste específicos

## Screenshots
(Se aplicável)

## Checklist
- [ ] Código segue os padrões do projeto
- [ ] Testes foram adicionados/atualizados
- [ ] Documentação foi atualizada
- [ ] Todos os testes passam
```

### Revisão de Código

Todos os PRs passam por revisão. Critérios:

- **Funcionalidade**: O código faz o que deveria fazer?
- **Legibilidade**: O código é fácil de entender?
- **Performance**: Há impactos de performance?
- **Segurança**: Há vulnerabilidades introduzidas?
- **Testes**: A cobertura de testes é adequada?

### Processo de Release

1. **Desenvolvimento**: Features desenvolvidas em branches
2. **Staging**: Testes em ambiente de staging
3. **Release**: Merge para main e deploy
4. **Hotfix**: Correções urgentes direto na main

### Comunicação

- **Issues**: Para bugs e sugestões
- **Discussions**: Para perguntas gerais
- **Discord**: Para chat em tempo real (link no README)

### Reconhecimento

Contribuidores são reconhecidos:
- Listados no README
- Mencionados nas release notes
- Badge de contribuidor no perfil

## Áreas que Precisam de Ajuda

### Alta Prioridade
- [ ] Testes automatizados
- [ ] Documentação de API
- [ ] Otimizações de performance
- [ ] Acessibilidade (a11y)

### Média Prioridade
- [ ] Internacionalização (i18n)
- [ ] Temas customizáveis
- [ ] Mobile responsiveness
- [ ] PWA features

### Baixa Prioridade
- [ ] Integração com redes sociais
- [ ] Analytics
- [ ] Admin dashboard
- [ ] Bot detection

## Recursos Úteis

### Documentação
- [Flask Documentation](https://flask.palletsprojects.com/)
- [React Documentation](https://reactjs.org/)
- [Socket.IO Documentation](https://socket.io/)
- [WebRTC Documentation](https://webrtc.org/)

### Ferramentas
- [Postman Collection](docs/postman_collection.json) para API testing
- [Docker Compose](docker-compose.yml) para ambiente local
- [GitHub Actions](.github/workflows/) para CI/CD

### Comunidade
- [Stack Overflow](https://stackoverflow.com/questions/tagged/omegle-chat)
- [Reddit Community](https://reddit.com/r/webdev)
- [Discord Server](https://discord.gg/omegle-chat)

## Código de Conduta

Este projeto segue o [Código de Conduta do Contributor Covenant](CODE_OF_CONDUCT.md). 
Ao participar, você concorda em seguir estes termos.

### Comportamento Esperado
- Seja respeitoso e inclusivo
- Aceite críticas construtivas
- Foque no que é melhor para a comunidade
- Demonstre empatia com outros membros

### Comportamento Inaceitável
- Linguagem ou imagens sexualizadas
- Trolling, insultos ou comentários depreciativos
- Assédio público ou privado
- Publicar informações privadas de terceiros

### Aplicação
Casos de comportamento abusivo podem ser reportados para [email@exemplo.com]. 
Todas as reclamações serão revisadas e investigadas.

## Agradecimentos

Obrigado por contribuir para tornar o OmegleChat melhor para todos! 🚀

