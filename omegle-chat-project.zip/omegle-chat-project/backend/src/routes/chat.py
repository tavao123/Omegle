from flask import Blueprint, request, jsonify
from flask_socketio import emit, join_room, leave_room, disconnect
import uuid
import random
from datetime import datetime

chat_bp = Blueprint('chat', __name__)

# Armazenar usuários conectados e salas de chat
connected_users = {}
waiting_users = []
active_rooms = {}

class ChatRoom:
    def __init__(self, room_id, user1_id, user2_id):
        self.room_id = room_id
        self.user1_id = user1_id
        self.user2_id = user2_id
        self.created_at = datetime.now()
        self.messages = []
    
    def add_message(self, user_id, message, message_type='text'):
        self.messages.append({
            'user_id': user_id,
            'message': message,
            'type': message_type,
            'timestamp': datetime.now().isoformat()
        })

@chat_bp.route('/status', methods=['GET'])
def get_status():
    """Retorna estatísticas do servidor"""
    return jsonify({
        'connected_users': len(connected_users),
        'waiting_users': len(waiting_users),
        'active_rooms': len(active_rooms),
        'status': 'online'
    })

def find_match_for_user(user_id):
    """Encontra um match para o usuário"""
    if len(waiting_users) >= 2:
        # Remove o usuário atual da lista de espera se estiver lá
        if user_id in waiting_users:
            waiting_users.remove(user_id)
        
        # Pega outro usuário da lista de espera
        if waiting_users:
            partner_id = waiting_users.pop(0)
            
            # Cria uma nova sala de chat
            room_id = str(uuid.uuid4())
            room = ChatRoom(room_id, user_id, partner_id)
            active_rooms[room_id] = room
            
            return room_id, partner_id
    
    return None, None

def cleanup_user(user_id):
    """Remove usuário de todas as estruturas de dados"""
    # Remove da lista de espera
    if user_id in waiting_users:
        waiting_users.remove(user_id)
    
    # Remove dos usuários conectados
    if user_id in connected_users:
        del connected_users[user_id]
    
    # Encontra e remove das salas ativas
    rooms_to_remove = []
    for room_id, room in active_rooms.items():
        if room.user1_id == user_id or room.user2_id == user_id:
            rooms_to_remove.append(room_id)
    
    for room_id in rooms_to_remove:
        del active_rooms[room_id]

