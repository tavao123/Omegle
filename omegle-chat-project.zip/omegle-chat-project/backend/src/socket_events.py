from flask_socketio import emit, join_room, leave_room, disconnect
from flask import request
from src.routes.chat import connected_users, waiting_users, active_rooms, find_match_for_user, cleanup_user
import uuid

def register_socket_events(socketio):
    """Registra todos os eventos de socket"""
    
    @socketio.on('connect')
    def handle_connect(auth):
        """Usuário se conectou"""
        user_id = str(uuid.uuid4())
        connected_users[user_id] = {
            'session_id': request.sid,
            'user_id': user_id,
            'status': 'connected'
        }
        
        emit('user_connected', {
            'user_id': user_id,
            'message': 'Conectado com sucesso!'
        })
        
        print(f"Usuário {user_id} conectado")
    
    @socketio.on('disconnect')
    def handle_disconnect():
        """Usuário se desconectou"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if user_id:
            # Notifica o parceiro se estiver em uma sala
            for room_id, room in active_rooms.items():
                if room.user1_id == user_id:
                    partner_id = room.user2_id
                    partner_session = connected_users.get(partner_id, {}).get('session_id')
                    if partner_session:
                        socketio.emit('partner_disconnected', room=partner_session)
                elif room.user2_id == user_id:
                    partner_id = room.user1_id
                    partner_session = connected_users.get(partner_id, {}).get('session_id')
                    if partner_session:
                        socketio.emit('partner_disconnected', room=partner_session)
            
            cleanup_user(user_id)
            print(f"Usuário {user_id} desconectado")
    
    @socketio.on('find_stranger')
    def handle_find_stranger():
        """Usuário quer encontrar um estranho"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            emit('error', {'message': 'Usuário não encontrado'})
            return
        
        # Adiciona à lista de espera
        if user_id not in waiting_users:
            waiting_users.append(user_id)
        
        # Tenta encontrar um match
        room_id, partner_id = find_match_for_user(user_id)
        
        if room_id and partner_id:
            # Match encontrado!
            user_session = connected_users[user_id]['session_id']
            partner_session = connected_users[partner_id]['session_id']
            
            # Adiciona ambos à sala
            join_room(room_id, sid=user_session)
            join_room(room_id, sid=partner_session)
            
            # Notifica ambos os usuários
            socketio.emit('match_found', {
                'room_id': room_id,
                'message': 'Estranho encontrado! Você pode começar a conversar.'
            }, room=room_id)
            
            print(f"Match encontrado: {user_id} e {partner_id} na sala {room_id}")
        else:
            emit('waiting_for_stranger', {
                'message': 'Procurando por um estranho... Aguarde.'
            })
    
    @socketio.on('send_message')
    def handle_send_message(data):
        """Usuário enviou uma mensagem"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            emit('error', {'message': 'Usuário não encontrado'})
            return
        
        message = data.get('message', '').strip()
        if not message:
            emit('error', {'message': 'Mensagem vazia'})
            return
        
        # Encontra a sala do usuário
        user_room = None
        for room_id, room in active_rooms.items():
            if room.user1_id == user_id or room.user2_id == user_id:
                user_room = room
                break
        
        if not user_room:
            emit('error', {'message': 'Você não está em uma conversa'})
            return
        
        # Adiciona a mensagem à sala
        user_room.add_message(user_id, message)
        
        # Envia a mensagem para todos na sala
        socketio.emit('new_message', {
            'message': message,
            'sender': 'stranger' if user_id != user_id else 'you',
            'timestamp': user_room.messages[-1]['timestamp']
        }, room=user_room.room_id)
    
    @socketio.on('disconnect_stranger')
    def handle_disconnect_stranger():
        """Usuário quer desconectar do estranho atual"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            emit('error', {'message': 'Usuário não encontrado'})
            return
        
        # Encontra a sala do usuário
        user_room = None
        partner_id = None
        for room_id, room in active_rooms.items():
            if room.user1_id == user_id:
                user_room = room
                partner_id = room.user2_id
                break
            elif room.user2_id == user_id:
                user_room = room
                partner_id = room.user1_id
                break
        
        if user_room:
            # Notifica o parceiro
            if partner_id and partner_id in connected_users:
                partner_session = connected_users[partner_id]['session_id']
                socketio.emit('stranger_disconnected', {
                    'message': 'O estranho se desconectou.'
                }, room=partner_session)
                
                # Remove o parceiro da sala
                leave_room(user_room.room_id, sid=partner_session)
            
            # Remove o usuário da sala
            leave_room(user_room.room_id, sid=request.sid)
            
            # Remove a sala
            del active_rooms[user_room.room_id]
            
            emit('disconnected_from_stranger', {
                'message': 'Você se desconectou do estranho.'
            })
    
    @socketio.on('webrtc_offer')
    def handle_webrtc_offer(data):
        """Manuseia oferta WebRTC para vídeo/áudio"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            return
        
        # Encontra o parceiro
        for room_id, room in active_rooms.items():
            if room.user1_id == user_id:
                partner_id = room.user2_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_offer', data, room=partner_session)
                break
            elif room.user2_id == user_id:
                partner_id = room.user1_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_offer', data, room=partner_session)
                break
    
    @socketio.on('webrtc_answer')
    def handle_webrtc_answer(data):
        """Manuseia resposta WebRTC"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            return
        
        # Encontra o parceiro
        for room_id, room in active_rooms.items():
            if room.user1_id == user_id:
                partner_id = room.user2_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_answer', data, room=partner_session)
                break
            elif room.user2_id == user_id:
                partner_id = room.user1_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_answer', data, room=partner_session)
                break
    
    @socketio.on('webrtc_ice_candidate')
    def handle_webrtc_ice_candidate(data):
        """Manuseia candidatos ICE do WebRTC"""
        user_id = None
        
        # Encontra o usuário pelo session_id
        for uid, user_data in connected_users.items():
            if user_data['session_id'] == request.sid:
                user_id = uid
                break
        
        if not user_id:
            return
        
        # Encontra o parceiro
        for room_id, room in active_rooms.items():
            if room.user1_id == user_id:
                partner_id = room.user2_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_ice_candidate', data, room=partner_session)
                break
            elif room.user2_id == user_id:
                partner_id = room.user1_id
                partner_session = connected_users.get(partner_id, {}).get('session_id')
                if partner_session:
                    socketio.emit('webrtc_ice_candidate', data, room=partner_session)
                break

