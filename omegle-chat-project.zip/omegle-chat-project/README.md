# OmegleChat - Clone Avançado do Omegle

Uma aplicação web moderna que replica as funcionalidades do Omegle, permitindo conversas anônimas entre estranhos através de chat de texto e vídeo em tempo real.

## 🚀 Características Principais

- **Chat de Texto em Tempo Real**: Conversas instantâneas via WebSocket
- **Chat de Vídeo/Áudio**: Comunicação por vídeo usando WebRTC
- **Sistema de Matching**: Algoritmo inteligente para conectar usuários
- **Interface Responsiva**: Design moderno que funciona em desktop e mobile
- **Conexões Anônimas**: Sem necessidade de cadastro ou login
- **Controles de Mídia**: Ligar/desligar câmera e microfone
- **Sistema de Salas**: Gerenciamento automático de salas de chat

## 🛠️ Tecnologias Utilizadas

### Backend
- **Flask**: Framework web Python
- **Flask-SocketIO**: WebSocket para comunicação em tempo real
- **Flask-CORS**: Suporte a Cross-Origin Resource Sharing
- **SQLAlchemy**: ORM para banco de dados (opcional)

### Frontend
- **React**: Biblioteca JavaScript para interface de usuário
- **Vite**: Build tool e servidor de desenvolvimento
- **Socket.IO Client**: Cliente WebSocket
- **Tailwind CSS**: Framework CSS utilitário
- **Shadcn/UI**: Componentes de interface modernos
- **Lucide Icons**: Ícones SVG

### Comunicação
- **WebSocket**: Para mensagens de texto em tempo real
- **WebRTC**: Para comunicação de vídeo e áudio peer-to-peer

## 📁 Estrutura do Projeto

```
omegle-chat/
├── backend/                 # Servidor Flask
│   ├── src/
│   │   ├── routes/         # Rotas da API
│   │   ├── models/         # Modelos de dados
│   │   ├── socket_events.py # Eventos WebSocket
│   │   └── main.py         # Ponto de entrada
│   ├── venv/               # Ambiente virtual Python
│   └── requirements.txt    # Dependências Python
├── frontend/               # Aplicação React
│   ├── src/
│   │   ├── components/     # Componentes React
│   │   ├── hooks/          # Hooks customizados
│   │   └── assets/         # Recursos estáticos
│   ├── public/             # Arquivos públicos
│   └── package.json        # Dependências Node.js
└── docs/                   # Documentação
```

## 🚀 Instalação e Execução

### Pré-requisitos
- Python 3.8+
- Node.js 16+
- npm ou pnpm

### Backend (Flask)

1. Clone o repositório:
```bash
git clone https://github.com/seu-usuario/omegle-chat.git
cd omegle-chat/backend
```

2. Crie um ambiente virtual:
```bash
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou
venv\Scripts\activate     # Windows
```

3. Instale as dependências:
```bash
pip install -r requirements.txt
```

4. Execute o servidor:
```bash
python src/main.py
```

O backend estará rodando em `http://localhost:5000`

### Frontend (React)

1. Navegue para o diretório frontend:
```bash
cd ../frontend
```

2. Instale as dependências:
```bash
pnpm install
# ou
npm install
```

3. Execute o servidor de desenvolvimento:
```bash
pnpm run dev
# ou
npm run dev
```

O frontend estará rodando em `http://localhost:5173`

## 🌐 Deploy

### GitHub Pages (Frontend apenas)

Para deploy do frontend no GitHub Pages:

1. Build da aplicação:
```bash
cd frontend
pnpm run build
```

2. Configure o GitHub Pages para usar a pasta `dist/`

**Nota**: O GitHub Pages só suporta sites estáticos. Para funcionalidade completa, você precisará hospedar o backend separadamente.

### Deploy Completo

Para deploy completo da aplicação, recomendamos:

**Backend**:
- Heroku
- Railway
- Render
- DigitalOcean App Platform

**Frontend**:
- Vercel
- Netlify
- GitHub Pages

## 🔧 Configuração

### Variáveis de Ambiente

Crie um arquivo `.env` no diretório backend:

```env
FLASK_ENV=development
SECRET_KEY=sua-chave-secreta-aqui
DATABASE_URL=sqlite:///app.db
```

### Configuração do Frontend

Atualize a URL do servidor no arquivo `src/hooks/useSocket.js`:

```javascript
const useSocket = (serverUrl = 'https://seu-backend.herokuapp.com') => {
  // ...
}
```

## 🎯 Como Usar

1. Acesse a aplicação no navegador
2. Clique em "Encontrar Estranho" para iniciar uma conversa
3. Aguarde ser conectado com outro usuário
4. Use o chat de texto ou inicie uma chamada de vídeo
5. Clique em "Próximo" para encontrar um novo estranho

## 🔒 Segurança e Privacidade

- Todas as conversas são anônimas
- Não armazenamos histórico de mensagens
- IDs de usuário são temporários e únicos por sessão
- Conexões WebRTC são peer-to-peer (não passam pelo servidor)

## 🤝 Contribuindo

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/AmazingFeature`)
3. Commit suas mudanças (`git commit -m 'Add some AmazingFeature'`)
4. Push para a branch (`git push origin feature/AmazingFeature`)
5. Abra um Pull Request

## 📝 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 🐛 Problemas Conhecidos

- WebRTC pode não funcionar em algumas redes corporativas
- Permissões de câmera/microfone são necessárias para vídeo chat
- Conexões podem ser instáveis em redes com NAT restritivo

## 📚 Documentação Adicional

- [Guia de Deploy](docs/DEPLOY.md)
- [API Reference](docs/API.md)
- [Arquitetura do Sistema](docs/ARCHITECTURE.md)

## 👥 Autores

- **Manus AI** - Desenvolvimento inicial

## 🙏 Agradecimentos

- Inspirado no Omegle original
- Comunidade React e Flask
- Contribuidores de código aberto

