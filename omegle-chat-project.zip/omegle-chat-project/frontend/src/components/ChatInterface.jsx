import React, { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Badge } from '@/components/ui/badge.jsx';
import { 
  Video, 
  VideoOff, 
  Mic, 
  MicOff, 
  Send, 
  Users, 
  MessageCircle,
  Phone,
  PhoneOff,
  SkipForward
} from 'lucide-react';
import useSocket from '../hooks/useSocket';
import useWebRTC from '../hooks/useWebRTC';
import './ChatInterface.css';

const ChatInterface = () => {
  const { socket, isConnected, userId, emit, on, off } = useSocket();
  const {
    localVideoRef,
    remoteVideoRef,
    isVideoEnabled,
    isAudioEnabled,
    isConnected: isWebRTCConnected,
    startLocalVideo,
    stopLocalVideo,
    toggleVideo,
    toggleAudio,
    createOffer,
    handleOffer,
    handleAnswer,
    handleIceCandidate,
    cleanup
  } = useWebRTC(socket);

  const [chatState, setChatState] = useState('disconnected'); // disconnected, waiting, connected
  const [messages, setMessages] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isVideoCall, setIsVideoCall] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState('Desconectado');
  
  const messagesEndRef = useRef(null);
  const chatContainerRef = useRef(null);

  // Auto scroll para a última mensagem
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Configurar eventos do socket
  useEffect(() => {
    if (!socket) return;

    const handleWaitingForStranger = (data) => {
      setChatState('waiting');
      setConnectionStatus('Procurando estranho...');
      setMessages([{ type: 'system', message: data.message, timestamp: new Date().toISOString() }]);
    };

    const handleMatchFound = (data) => {
      setChatState('connected');
      setConnectionStatus('Conectado com estranho');
      setMessages(prev => [...prev, { 
        type: 'system', 
        message: data.message, 
        timestamp: new Date().toISOString() 
      }]);
    };

    const handleNewMessage = (data) => {
      setMessages(prev => [...prev, {
        type: 'stranger',
        message: data.message,
        timestamp: data.timestamp
      }]);
    };

    const handleStrangerDisconnected = (data) => {
      setChatState('disconnected');
      setConnectionStatus('Estranho desconectou');
      setMessages(prev => [...prev, { 
        type: 'system', 
        message: data.message, 
        timestamp: new Date().toISOString() 
      }]);
      cleanup();
      setIsVideoCall(false);
    };

    const handlePartnerDisconnected = () => {
      setChatState('disconnected');
      setConnectionStatus('Parceiro desconectou');
      setMessages(prev => [...prev, { 
        type: 'system', 
        message: 'O estranho se desconectou.', 
        timestamp: new Date().toISOString() 
      }]);
      cleanup();
      setIsVideoCall(false);
    };

    const handleDisconnectedFromStranger = (data) => {
      setChatState('disconnected');
      setConnectionStatus('Desconectado');
      setMessages(prev => [...prev, { 
        type: 'system', 
        message: data.message, 
        timestamp: new Date().toISOString() 
      }]);
      cleanup();
      setIsVideoCall(false);
    };

    // Eventos WebRTC
    const handleWebRTCOffer = (data) => {
      handleOffer(data);
    };

    const handleWebRTCAnswer = (data) => {
      handleAnswer(data);
    };

    const handleWebRTCIceCandidate = (data) => {
      handleIceCandidate(data);
    };

    // Registrar eventos
    on('waiting_for_stranger', handleWaitingForStranger);
    on('match_found', handleMatchFound);
    on('new_message', handleNewMessage);
    on('stranger_disconnected', handleStrangerDisconnected);
    on('partner_disconnected', handlePartnerDisconnected);
    on('disconnected_from_stranger', handleDisconnectedFromStranger);
    on('webrtc_offer', handleWebRTCOffer);
    on('webrtc_answer', handleWebRTCAnswer);
    on('webrtc_ice_candidate', handleWebRTCIceCandidate);

    // Cleanup
    return () => {
      off('waiting_for_stranger', handleWaitingForStranger);
      off('match_found', handleMatchFound);
      off('new_message', handleNewMessage);
      off('stranger_disconnected', handleStrangerDisconnected);
      off('partner_disconnected', handlePartnerDisconnected);
      off('disconnected_from_stranger', handleDisconnectedFromStranger);
      off('webrtc_offer', handleWebRTCOffer);
      off('webrtc_answer', handleWebRTCAnswer);
      off('webrtc_ice_candidate', handleWebRTCIceCandidate);
    };
  }, [socket, on, off, handleOffer, handleAnswer, handleIceCandidate, cleanup]);

  // Atualizar status de conexão
  useEffect(() => {
    if (!isConnected) {
      setConnectionStatus('Desconectado do servidor');
      setChatState('disconnected');
    } else if (chatState === 'disconnected' && isConnected) {
      setConnectionStatus('Conectado ao servidor');
    }
  }, [isConnected, chatState]);

  const handleFindStranger = () => {
    if (socket && isConnected) {
      emit('find_stranger');
      setMessages([]);
    }
  };

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (currentMessage.trim() && socket && chatState === 'connected') {
      // Adicionar mensagem própria
      setMessages(prev => [...prev, {
        type: 'you',
        message: currentMessage,
        timestamp: new Date().toISOString()
      }]);

      // Enviar para o servidor
      emit('send_message', { message: currentMessage });
      setCurrentMessage('');
    }
  };

  const handleDisconnectStranger = () => {
    if (socket) {
      emit('disconnect_stranger');
    }
  };

  const handleStartVideoCall = async () => {
    try {
      await startLocalVideo();
      setIsVideoCall(true);
      createOffer();
    } catch (error) {
      console.error('Erro ao iniciar vídeo:', error);
      alert('Erro ao acessar câmera/microfone. Verifique as permissões.');
    }
  };

  const handleEndVideoCall = () => {
    cleanup();
    setIsVideoCall(false);
  };

  const getStatusColor = () => {
    switch (chatState) {
      case 'connected': return 'bg-green-500';
      case 'waiting': return 'bg-yellow-500';
      default: return 'bg-red-500';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-6">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">OmegleChat</h1>
          <p className="text-gray-600">Converse com estranhos do mundo todo</p>
          <div className="flex items-center justify-center mt-4 space-x-2">
            <div className={`w-3 h-3 rounded-full ${getStatusColor()}`}></div>
            <span className="text-sm font-medium">{connectionStatus}</span>
            {userId && <Badge variant="outline">ID: {userId.slice(0, 8)}</Badge>}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Área de Vídeo */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Video className="w-5 h-5" />
                <span>Vídeo Chat</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Vídeos */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Vídeo Local */}
                  <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video">
                    <video
                      ref={localVideoRef}
                      autoPlay
                      muted
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                      Você
                    </div>
                    {!isVideoEnabled && (
                      <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                        <VideoOff className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* Vídeo Remoto */}
                  <div className="relative bg-gray-900 rounded-lg overflow-hidden aspect-video">
                    <video
                      ref={remoteVideoRef}
                      autoPlay
                      playsInline
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-2 left-2 bg-black bg-opacity-50 text-white px-2 py-1 rounded text-xs">
                      Estranho
                    </div>
                    {!isWebRTCConnected && (
                      <div className="absolute inset-0 bg-gray-800 flex items-center justify-center">
                        <div className="text-center text-gray-400">
                          <Users className="w-8 h-8 mx-auto mb-2" />
                          <p className="text-sm">Aguardando vídeo...</p>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Controles de Vídeo */}
                <div className="flex justify-center space-x-2">
                  {!isVideoCall ? (
                    <Button
                      onClick={handleStartVideoCall}
                      disabled={chatState !== 'connected'}
                      className="flex items-center space-x-2"
                    >
                      <Video className="w-4 h-4" />
                      <span>Iniciar Vídeo</span>
                    </Button>
                  ) : (
                    <>
                      <Button
                        onClick={toggleVideo}
                        variant={isVideoEnabled ? "default" : "destructive"}
                        size="sm"
                      >
                        {isVideoEnabled ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
                      </Button>
                      <Button
                        onClick={toggleAudio}
                        variant={isAudioEnabled ? "default" : "destructive"}
                        size="sm"
                      >
                        {isAudioEnabled ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
                      </Button>
                      <Button
                        onClick={handleEndVideoCall}
                        variant="destructive"
                        size="sm"
                      >
                        <PhoneOff className="w-4 h-4" />
                      </Button>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Área de Chat */}
          <Card className="lg:col-span-1">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <MessageCircle className="w-5 h-5" />
                <span>Chat de Texto</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Mensagens */}
                <div 
                  ref={chatContainerRef}
                  className="h-96 overflow-y-auto border rounded-lg p-4 bg-white space-y-2"
                >
                  {messages.map((msg, index) => (
                    <div
                      key={index}
                      className={`flex ${msg.type === 'you' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-xs px-3 py-2 rounded-lg text-sm ${
                          msg.type === 'you'
                            ? 'bg-blue-500 text-white'
                            : msg.type === 'stranger'
                            ? 'bg-gray-200 text-gray-800'
                            : 'bg-yellow-100 text-yellow-800 text-center w-full'
                        }`}
                      >
                        {msg.message}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>

                {/* Input de Mensagem */}
                <form onSubmit={handleSendMessage} className="flex space-x-2">
                  <Input
                    value={currentMessage}
                    onChange={(e) => setCurrentMessage(e.target.value)}
                    placeholder="Digite sua mensagem..."
                    disabled={chatState !== 'connected'}
                    className="flex-1"
                  />
                  <Button
                    type="submit"
                    disabled={chatState !== 'connected' || !currentMessage.trim()}
                    size="sm"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </form>

                {/* Controles de Conexão */}
                <div className="flex space-x-2">
                  {chatState === 'disconnected' && (
                    <Button
                      onClick={handleFindStranger}
                      disabled={!isConnected}
                      className="flex-1 flex items-center justify-center space-x-2"
                    >
                      <Users className="w-4 h-4" />
                      <span>Encontrar Estranho</span>
                    </Button>
                  )}
                  
                  {(chatState === 'waiting' || chatState === 'connected') && (
                    <Button
                      onClick={handleDisconnectStranger}
                      variant="destructive"
                      className="flex-1 flex items-center justify-center space-x-2"
                    >
                      <SkipForward className="w-4 h-4" />
                      <span>Próximo</span>
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default ChatInterface;

