import { useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const useSocket = (serverUrl = 'http://localhost:5000') => {
  const socketRef = useRef(null);
  const [isConnected, setIsConnected] = useState(false);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    // Criar conexão com o servidor
    socketRef.current = io(serverUrl, {
      transports: ['websocket', 'polling']
    });

    const socket = socketRef.current;

    // Eventos de conexão
    socket.on('connect', () => {
      setIsConnected(true);
      console.log('Conectado ao servidor');
    });

    socket.on('disconnect', () => {
      setIsConnected(false);
      console.log('Desconectado do servidor');
    });

    socket.on('user_connected', (data) => {
      setUserId(data.user_id);
      console.log('ID do usuário:', data.user_id);
    });

    // Cleanup na desmontagem
    return () => {
      if (socket) {
        socket.disconnect();
      }
    };
  }, [serverUrl]);

  const emit = (event, data) => {
    if (socketRef.current) {
      socketRef.current.emit(event, data);
    }
  };

  const on = (event, callback) => {
    if (socketRef.current) {
      socketRef.current.on(event, callback);
    }
  };

  const off = (event, callback) => {
    if (socketRef.current) {
      socketRef.current.off(event, callback);
    }
  };

  return {
    socket: socketRef.current,
    isConnected,
    userId,
    emit,
    on,
    off
  };
};

export default useSocket;

