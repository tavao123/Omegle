# Arquitetura do Sistema - OmegleChat

Este documento descreve a arquitetura técnica da aplicação OmegleChat, incluindo componentes, fluxos de dados e decisões de design.

## Visão Geral

O OmegleChat é uma aplicação web distribuída que permite conversas anônimas em tempo real entre usuários. A arquitetura segue o padrão cliente-servidor com comunicação bidirecional via WebSockets.

```
┌─────────────────┐    WebSocket/HTTP    ┌─────────────────┐
│                 │ ◄─────────────────► │                 │
│   Frontend      │                     │    Backend      │
│   (React)       │                     │   (Flask)       │
│                 │                     │                 │
└─────────────────┘                     └─────────────────┘
         │                                       │
         │                                       │
         ▼                                       ▼
┌─────────────────┐                     ┌─────────────────┐
│   WebRTC P2P    │ ◄─────────────────► │   SQLite DB     │
│   (Vídeo/Áudio) │                     │   (Opcional)    │
└─────────────────┘                     └─────────────────┘
```

## Componentes Principais

### Frontend (React)

**Responsabilidades:**
- Interface de usuário responsiva
- Gerenciamento de estado local
- Comunicação WebSocket com backend
- Implementação WebRTC para vídeo/áudio
- Controles de mídia (câmera/microfone)

**Estrutura de Componentes:**
```
src/
├── components/
│   ├── ChatInterface.jsx      # Componente principal
│   └── ui/                    # Componentes de interface
├── hooks/
│   ├── useSocket.js           # Hook para WebSocket
│   └── useWebRTC.js           # Hook para WebRTC
└── assets/                    # Recursos estáticos
```

**Tecnologias:**
- React 18 com Hooks
- Socket.IO Client para WebSocket
- WebRTC API nativa
- Tailwind CSS para estilização
- Vite como bundler

### Backend (Flask)

**Responsabilidades:**
- Gerenciamento de conexões WebSocket
- Sistema de matching de usuários
- Roteamento de mensagens
- Sinalização WebRTC
- API REST para status

**Estrutura de Módulos:**
```
src/
├── main.py                    # Ponto de entrada
├── socket_events.py           # Eventos WebSocket
├── routes/
│   ├── chat.py               # Rotas de chat
│   └── user.py               # Rotas de usuário
└── models/
    └── user.py               # Modelos de dados
```

**Tecnologias:**
- Flask como framework web
- Flask-SocketIO para WebSocket
- SQLAlchemy para ORM (opcional)
- Flask-CORS para CORS

## Fluxo de Dados

### 1. Conexão de Usuário

```mermaid
sequenceDiagram
    participant U as Usuário
    participant F as Frontend
    participant B as Backend
    
    U->>F: Acessa aplicação
    F->>B: WebSocket connect
    B->>F: user_connected + user_id
    F->>U: Interface atualizada
```

### 2. Sistema de Matching

```mermaid
sequenceDiagram
    participant U1 as Usuário 1
    participant U2 as Usuário 2
    participant B as Backend
    
    U1->>B: find_stranger
    B->>U1: waiting_for_stranger
    U2->>B: find_stranger
    B->>B: Criar sala de chat
    B->>U1: match_found + room_id
    B->>U2: match_found + room_id
```

### 3. Chat de Texto

```mermaid
sequenceDiagram
    participant U1 as Usuário 1
    participant B as Backend
    participant U2 as Usuário 2
    
    U1->>B: send_message
    B->>B: Validar e processar
    B->>U1: new_message (echo)
    B->>U2: new_message
```

### 4. Chat de Vídeo (WebRTC)

```mermaid
sequenceDiagram
    participant U1 as Usuário 1
    participant B as Backend
    participant U2 as Usuário 2
    
    U1->>B: webrtc_offer
    B->>U2: webrtc_offer
    U2->>B: webrtc_answer
    B->>U1: webrtc_answer
    U1->>U2: Conexão P2P direta
    Note over U1,U2: Vídeo/áudio via WebRTC
```

## Estruturas de Dados

### Usuário Conectado
```python
{
    'session_id': 'socket_session_id',
    'user_id': 'uuid4_string',
    'status': 'connected'|'waiting'|'chatting'
}
```

### Sala de Chat
```python
class ChatRoom:
    room_id: str          # UUID da sala
    user1_id: str         # ID do primeiro usuário
    user2_id: str         # ID do segundo usuário
    created_at: datetime  # Timestamp de criação
    messages: list        # Histórico de mensagens (opcional)
```

### Mensagem
```python
{
    'user_id': str,
    'message': str,
    'type': 'text'|'system',
    'timestamp': str
}
```

## Algoritmo de Matching

O sistema utiliza um algoritmo simples de fila FIFO (First In, First Out):

```python
def find_match_for_user(user_id):
    if len(waiting_users) >= 2:
        # Remove usuário atual se estiver na fila
        if user_id in waiting_users:
            waiting_users.remove(user_id)
        
        # Pega próximo usuário da fila
        if waiting_users:
            partner_id = waiting_users.pop(0)
            
            # Cria nova sala
            room_id = str(uuid.uuid4())
            room = ChatRoom(room_id, user_id, partner_id)
            active_rooms[room_id] = room
            
            return room_id, partner_id
    
    return None, None
```

**Características:**
- Matching instantâneo quando possível
- Sem critérios de filtro (totalmente anônimo)
- Balanceamento automático de carga
- Cleanup automático de usuários desconectados

## Comunicação WebRTC

### Sinalização

O backend atua como servidor de sinalização para WebRTC:

1. **Offer/Answer**: Troca de descrições de sessão
2. **ICE Candidates**: Descoberta de conectividade
3. **Relay**: Encaminhamento de mensagens entre peers

### Configuração STUN/TURN

```javascript
const pcConfig = {
    iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
    ]
};
```

**Limitações:**
- Apenas servidores STUN públicos
- Sem servidores TURN (pode falhar em NATs restritivos)
- Conexão P2P direta necessária

## Gerenciamento de Estado

### Frontend (React)

```javascript
// Estado global via hooks
const [chatState, setChatState] = useState('disconnected');
const [messages, setMessages] = useState([]);
const [isConnected, setIsConnected] = useState(false);

// Estados WebRTC
const [isVideoEnabled, setIsVideoEnabled] = useState(false);
const [isAudioEnabled, setIsAudioEnabled] = useState(false);
```

### Backend (Flask)

```python
# Estado em memória (não persistente)
connected_users = {}      # {user_id: user_data}
waiting_users = []        # [user_id, ...]
active_rooms = {}         # {room_id: ChatRoom}
```

**Limitações:**
- Estado perdido em restart do servidor
- Não escalável para múltiplas instâncias
- Sem persistência de dados

## Segurança

### Medidas Implementadas

1. **CORS**: Configurado para permitir origens específicas
2. **Rate Limiting**: Prevenção de spam (planejado)
3. **Validação**: Sanitização de mensagens
4. **Anonimato**: Sem armazenamento de dados pessoais

### Vulnerabilidades Conhecidas

1. **DDoS**: Sem proteção contra ataques de negação de serviço
2. **Spam**: Rate limiting não implementado
3. **XSS**: Sanitização básica de mensagens
4. **WebRTC**: Exposição de IP em conexões P2P

### Melhorias Recomendadas

```python
# Rate limiting
from flask_limiter import Limiter

limiter = Limiter(
    app,
    key_func=lambda: request.remote_addr,
    default_limits=["100 per hour"]
)

# Validação de mensagens
import bleach

def sanitize_message(message):
    return bleach.clean(message, strip=True)
```

## Performance

### Métricas Atuais

- **Latência WebSocket**: < 50ms (local)
- **Throughput**: ~1000 mensagens/segundo
- **Conexões simultâneas**: Limitado pela memória
- **Tempo de matching**: < 1 segundo

### Otimizações

1. **Connection Pooling**: Para banco de dados
2. **Message Queuing**: Para alta concorrência
3. **Load Balancing**: Para múltiplas instâncias
4. **CDN**: Para assets estáticos

### Monitoramento

```python
# Métricas básicas
@app.route('/api/metrics')
def get_metrics():
    return {
        'connected_users': len(connected_users),
        'active_rooms': len(active_rooms),
        'waiting_users': len(waiting_users),
        'uptime': time.time() - start_time
    }
```

## Escalabilidade

### Limitações Atuais

1. **Single Instance**: Apenas uma instância do backend
2. **In-Memory State**: Estado não compartilhado
3. **No Load Balancing**: Sem distribuição de carga

### Soluções Propostas

#### Redis para Estado Compartilhado

```python
import redis

redis_client = redis.Redis(host='localhost', port=6379)

# Armazenar usuários conectados
def add_connected_user(user_id, data):
    redis_client.hset('connected_users', user_id, json.dumps(data))

# Pub/Sub para mensagens
def publish_message(room_id, message):
    redis_client.publish(f'room:{room_id}', json.dumps(message))
```

#### Message Queue com Celery

```python
from celery import Celery

celery = Celery('omegle')

@celery.task
def process_message(room_id, message):
    # Processar mensagem assincronamente
    pass
```

#### Load Balancer com Nginx

```nginx
upstream backend {
    server backend1:5000;
    server backend2:5000;
    server backend3:5000;
}

server {
    location / {
        proxy_pass http://backend;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
```

## Deployment

### Arquitetura de Produção

```
Internet
    │
    ▼
┌─────────────┐
│   CDN       │ (Frontend estático)
│ (Vercel)    │
└─────────────┘
    │
    ▼
┌─────────────┐
│ Load        │
│ Balancer    │
└─────────────┘
    │
    ▼
┌─────────────┐    ┌─────────────┐
│ Backend     │    │   Redis     │
│ Instance 1  │◄──►│   Cluster   │
└─────────────┘    └─────────────┘
    │
    ▼
┌─────────────┐    ┌─────────────┐
│ Backend     │    │ PostgreSQL  │
│ Instance 2  │◄──►│  Database   │
└─────────────┘    └─────────────┘
```

### Containers Docker

```dockerfile
# Backend Dockerfile
FROM python:3.9-slim

WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt

COPY src/ ./src/
EXPOSE 5000

CMD ["python", "src/main.py"]
```

```dockerfile
# Frontend Dockerfile
FROM node:16-alpine

WORKDIR /app
COPY package.json pnpm-lock.yaml ./
RUN npm install -g pnpm && pnpm install

COPY . .
RUN pnpm run build

FROM nginx:alpine
COPY --from=0 /app/dist /usr/share/nginx/html
```

## Testes

### Estratégia de Testes

1. **Unit Tests**: Componentes individuais
2. **Integration Tests**: Fluxos completos
3. **Load Tests**: Performance sob carga
4. **E2E Tests**: Cenários de usuário

### Ferramentas

```python
# Backend - pytest
def test_user_connection():
    client = socketio.test_client(app)
    assert client.is_connected()

def test_message_routing():
    # Testar roteamento de mensagens
    pass
```

```javascript
// Frontend - Jest + React Testing Library
test('should connect to server', () => {
    render(<ChatInterface />);
    expect(screen.getByText('Conectado')).toBeInTheDocument();
});
```

## Roadmap Técnico

### Fase 1: Estabilização
- [ ] Implementar rate limiting
- [ ] Adicionar logging estruturado
- [ ] Melhorar tratamento de erros
- [ ] Testes automatizados

### Fase 2: Escalabilidade
- [ ] Redis para estado compartilhado
- [ ] Load balancing
- [ ] Métricas e monitoramento
- [ ] CI/CD pipeline

### Fase 3: Funcionalidades
- [ ] Salas temáticas
- [ ] Filtros de matching
- [ ] Moderação automática
- [ ] Mobile app

### Fase 4: Enterprise
- [ ] Multi-tenancy
- [ ] Analytics avançados
- [ ] API pública
- [ ] Integração com terceiros

