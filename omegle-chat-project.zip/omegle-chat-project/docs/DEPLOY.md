# Guia de Deploy - OmegleChat

Este documento fornece instruções detalhadas para fazer deploy da aplicação OmegleChat em diferentes plataformas.

## Visão Geral da Arquitetura

A aplicação OmegleChat consiste em dois componentes principais:

1. **Backend (Flask + SocketIO)**: Servidor Python que gerencia WebSockets, matching de usuários e API REST
2. **Frontend (React)**: Interface de usuário que se conecta ao backend via WebSocket

## Opções de Deploy

### 1. Deploy Separado (Recomendado)

#### Backend - Heroku

1. **Preparação**:
```bash
cd backend
echo "web: python src/main.py" > Procfile
```

2. **Criar aplicação no Heroku**:
```bash
heroku create seu-app-backend
```

3. **Configurar variáveis de ambiente**:
```bash
heroku config:set FLASK_ENV=production
heroku config:set SECRET_KEY=sua-chave-secreta-super-segura
```

4. **Deploy**:
```bash
git add .
git commit -m "Deploy backend"
git push heroku main
```

#### Frontend - Vercel

1. **Configurar build**:
```bash
cd frontend
# Atualizar serverUrl no useSocket.js para a URL do Heroku
```

2. **Deploy via Vercel CLI**:
```bash
npm i -g vercel
vercel --prod
```

#### Frontend - Netlify

1. **Build local**:
```bash
cd frontend
pnpm run build
```

2. **Deploy via Netlify CLI**:
```bash
npm i -g netlify-cli
netlify deploy --prod --dir=dist
```

### 2. Deploy no Railway (Full-Stack)

Railway suporta tanto backend quanto frontend em um único projeto:

1. **Conectar repositório**:
   - Acesse railway.app
   - Conecte seu repositório GitHub

2. **Configurar serviços**:
   - Backend: Detecta automaticamente Python/Flask
   - Frontend: Configure build command: `cd frontend && pnpm run build`

3. **Variáveis de ambiente**:
```
FLASK_ENV=production
SECRET_KEY=sua-chave-secreta
PORT=5000
```

### 3. Deploy no Render

#### Backend

1. **Criar Web Service**:
   - Build Command: `cd backend && pip install -r requirements.txt`
   - Start Command: `cd backend && python src/main.py`

2. **Configurar variáveis**:
```
FLASK_ENV=production
SECRET_KEY=sua-chave-secreta
```

#### Frontend

1. **Criar Static Site**:
   - Build Command: `cd frontend && pnpm install && pnpm run build`
   - Publish Directory: `frontend/dist`

### 4. GitHub Pages (Frontend apenas)

**Limitação**: GitHub Pages só suporta sites estáticos. O backend deve ser hospedado separadamente.

1. **Configurar vite.config.js**:
```javascript
export default defineConfig({
  base: '/nome-do-repositorio/',
  // ... outras configurações
})
```

2. **Build e deploy**:
```bash
cd frontend
pnpm run build
# Copiar conteúdo de dist/ para branch gh-pages
```

3. **Automatizar com GitHub Actions**:
```yaml
# .github/workflows/deploy.yml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Setup Node
      uses: actions/setup-node@v2
      with:
        node-version: '16'
    - name: Install dependencies
      run: cd frontend && npm install
    - name: Build
      run: cd frontend && npm run build
    - name: Deploy
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./frontend/dist
```

## Configurações de Produção

### Backend

1. **Configurar CORS para produção**:
```python
# src/main.py
CORS(app, origins=["https://seu-frontend.vercel.app"])
```

2. **Usar servidor WSGI**:
```bash
pip install gunicorn
# Procfile: web: gunicorn --worker-class eventlet -w 1 --bind 0.0.0.0:$PORT src.main:app
```

3. **Configurar logging**:
```python
import logging
logging.basicConfig(level=logging.INFO)
```

### Frontend

1. **Configurar URL do backend**:
```javascript
// src/hooks/useSocket.js
const serverUrl = process.env.NODE_ENV === 'production' 
  ? 'https://seu-backend.herokuapp.com'
  : 'http://localhost:5000';
```

2. **Otimizar build**:
```javascript
// vite.config.js
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          socket: ['socket.io-client']
        }
      }
    }
  }
})
```

## Monitoramento e Logs

### Heroku

```bash
# Ver logs em tempo real
heroku logs --tail -a seu-app-backend

# Configurar alertas
heroku addons:create papertrail -a seu-app-backend
```

### Railway

- Logs disponíveis no dashboard
- Métricas automáticas de CPU/RAM

### Render

- Dashboard com logs e métricas
- Alertas automáticos por email

## Troubleshooting

### Problemas Comuns

1. **CORS Error**:
   - Verificar configuração de origins no backend
   - Certificar que URLs estão corretas

2. **WebSocket não conecta**:
   - Verificar se o servidor suporta WebSockets
   - Testar com polling como fallback

3. **Build falha**:
   - Verificar versões do Node.js/Python
   - Limpar cache: `pnpm store prune`

### Logs de Debug

```python
# Backend - adicionar logs
import logging
logging.basicConfig(level=logging.DEBUG)

@socketio.on('connect')
def handle_connect():
    logging.info(f'User connected: {request.sid}')
```

```javascript
// Frontend - debug WebSocket
socket.on('connect', () => {
  console.log('Connected to server');
});

socket.on('disconnect', () => {
  console.log('Disconnected from server');
});
```

## Segurança em Produção

1. **HTTPS obrigatório**:
   - Usar certificados SSL
   - Redirecionar HTTP para HTTPS

2. **Rate limiting**:
```python
from flask_limiter import Limiter

limiter = Limiter(
    app,
    key_func=lambda: request.remote_addr,
    default_limits=["100 per hour"]
)
```

3. **Validação de entrada**:
```python
from flask_wtf.csrf import CSRFProtect

csrf = CSRFProtect(app)
```

## Performance

1. **CDN para frontend**:
   - Vercel/Netlify incluem CDN automaticamente
   - Para outros, usar CloudFlare

2. **Cache de assets**:
```javascript
// vite.config.js
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        assetFileNames: 'assets/[name].[hash][extname]'
      }
    }
  }
})
```

3. **Compressão**:
```python
from flask_compress import Compress

Compress(app)
```

## Backup e Recuperação

1. **Banco de dados**:
   - Heroku Postgres: backups automáticos
   - Railway: snapshots manuais

2. **Código**:
   - Git como backup principal
   - Tags para releases estáveis

## Custos Estimados

| Plataforma | Backend | Frontend | Total/mês |
|------------|---------|----------|-----------|
| Heroku + Vercel | $7 | Grátis | $7 |
| Railway | $5 | Incluído | $5 |
| Render | $7 | Grátis | $7 |
| GitHub Pages | N/A | Grátis | Apenas backend |

## Próximos Passos

1. Escolher plataforma de deploy
2. Configurar domínio customizado
3. Implementar monitoramento
4. Configurar CI/CD
5. Testes de carga

