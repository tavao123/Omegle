# API Reference - OmegleChat

Esta documentação descreve todas as APIs REST e eventos WebSocket disponíveis no backend do OmegleChat.

## Base URL

```
Desenvolvimento: http://localhost:5000
Produção: https://seu-backend.herokuapp.com
```

## Autenticação

A aplicação não requer autenticação. Todos os usuários são anônimos e identificados por IDs únicos gerados automaticamente.

## REST API

### GET /api/status

Retorna o status atual do servidor e estatísticas de usuários.

**Resposta:**
```json
{
  "status": "online",
  "connected_users": 5,
  "waiting_users": 2,
  "active_rooms": 1
}
```

**Campos:**
- `status`: Status do servidor ("online" ou "offline")
- `connected_users`: Número total de usuários conectados
- `waiting_users`: Número de usuários aguardando match
- `active_rooms`: Número de salas de chat ativas

## WebSocket Events

### Eventos do Cliente para Servidor

#### `connect`
Conecta o usuário ao servidor.

**Resposta do servidor:**
```json
{
  "event": "user_connected",
  "data": {
    "user_id": "649c98d5-da52-4105-8f29-0906aec3eefd",
    "message": "Conectado com sucesso!"
  }
}
```

#### `find_stranger`
Solicita para encontrar um estranho para conversar.

**Sem parâmetros**

**Possíveis respostas:**
1. Se encontrou match:
```json
{
  "event": "match_found",
  "data": {
    "room_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
    "message": "Estranho encontrado! Você pode começar a conversar."
  }
}
```

2. Se não encontrou match:
```json
{
  "event": "waiting_for_stranger",
  "data": {
    "message": "Procurando por um estranho... Aguarde."
  }
}
```

#### `send_message`
Envia uma mensagem de texto para o estranho.

**Parâmetros:**
```json
{
  "message": "Olá, como você está?"
}
```

**Resposta (para todos na sala):**
```json
{
  "event": "new_message",
  "data": {
    "message": "Olá, como você está?",
    "sender": "stranger",
    "timestamp": "2024-01-15T10:30:00.000Z"
  }
}
```

#### `disconnect_stranger`
Desconecta do estranho atual.

**Sem parâmetros**

**Resposta:**
```json
{
  "event": "disconnected_from_stranger",
  "data": {
    "message": "Você se desconectou do estranho."
  }
}
```

#### `webrtc_offer`
Envia uma oferta WebRTC para iniciar chamada de vídeo.

**Parâmetros:**
```json
{
  "offer": {
    "type": "offer",
    "sdp": "v=0\r\no=- 123456789 2 IN IP4 127.0.0.1\r\n..."
  }
}
```

#### `webrtc_answer`
Responde a uma oferta WebRTC.

**Parâmetros:**
```json
{
  "answer": {
    "type": "answer",
    "sdp": "v=0\r\no=- 987654321 2 IN IP4 127.0.0.1\r\n..."
  }
}
```

#### `webrtc_ice_candidate`
Envia candidato ICE para estabelecer conexão WebRTC.

**Parâmetros:**
```json
{
  "candidate": {
    "candidate": "candidate:1 1 UDP 2130706431 192.168.1.100 54400 typ host",
    "sdpMLineIndex": 0,
    "sdpMid": "0"
  }
}
```

### Eventos do Servidor para Cliente

#### `user_connected`
Confirmação de conexão bem-sucedida.

```json
{
  "user_id": "649c98d5-da52-4105-8f29-0906aec3eefd",
  "message": "Conectado com sucesso!"
}
```

#### `waiting_for_stranger`
Usuário está na fila aguardando match.

```json
{
  "message": "Procurando por um estranho... Aguarde."
}
```

#### `match_found`
Match encontrado, conversa pode começar.

```json
{
  "room_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "message": "Estranho encontrado! Você pode começar a conversar."
}
```

#### `new_message`
Nova mensagem recebida do estranho.

```json
{
  "message": "Oi! Tudo bem?",
  "sender": "stranger",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

#### `stranger_disconnected`
O estranho se desconectou.

```json
{
  "message": "O estranho se desconectou."
}
```

#### `partner_disconnected`
O parceiro se desconectou (evento interno).

```json
{
  "message": "O parceiro se desconectou."
}
```

#### `disconnected_from_stranger`
Confirmação de desconexão do estranho.

```json
{
  "message": "Você se desconectou do estranho."
}
```

#### `webrtc_offer`
Oferta WebRTC recebida do estranho.

```json
{
  "offer": {
    "type": "offer",
    "sdp": "v=0\r\no=- 123456789 2 IN IP4 127.0.0.1\r\n..."
  }
}
```

#### `webrtc_answer`
Resposta WebRTC recebida do estranho.

```json
{
  "answer": {
    "type": "answer",
    "sdp": "v=0\r\no=- 987654321 2 IN IP4 127.0.0.1\r\n..."
  }
}
```

#### `webrtc_ice_candidate`
Candidato ICE recebido do estranho.

```json
{
  "candidate": {
    "candidate": "candidate:1 1 UDP 2130706431 192.168.1.100 54400 typ host",
    "sdpMLineIndex": 0,
    "sdpMid": "0"
  }
}
```

#### `error`
Erro ocorrido no servidor.

```json
{
  "message": "Descrição do erro"
}
```

## Fluxo de Conexão

### 1. Conexão Inicial
```
Cliente -> connect -> Servidor
Servidor -> user_connected -> Cliente
```

### 2. Encontrar Estranho
```
Cliente -> find_stranger -> Servidor
Servidor -> waiting_for_stranger -> Cliente (se não há match)
Servidor -> match_found -> Ambos clientes (se há match)
```

### 3. Chat de Texto
```
Cliente A -> send_message -> Servidor
Servidor -> new_message -> Cliente B
```

### 4. Chat de Vídeo
```
Cliente A -> webrtc_offer -> Servidor -> Cliente B
Cliente B -> webrtc_answer -> Servidor -> Cliente A
Cliente A/B -> webrtc_ice_candidate -> Servidor -> Cliente B/A
```

### 5. Desconexão
```
Cliente -> disconnect_stranger -> Servidor
Servidor -> disconnected_from_stranger -> Cliente
Servidor -> stranger_disconnected -> Parceiro
```

## Códigos de Erro

| Código | Descrição |
|--------|-----------|
| `USER_NOT_FOUND` | Usuário não encontrado na sessão |
| `EMPTY_MESSAGE` | Mensagem vazia não permitida |
| `NOT_IN_CHAT` | Usuário não está em uma conversa |
| `WEBSOCKET_ERROR` | Erro na conexão WebSocket |

## Rate Limiting

- Máximo 100 mensagens por minuto por usuário
- Máximo 10 tentativas de conexão por minuto por IP
- Máximo 5 tentativas de match por minuto por usuário

## Exemplos de Uso

### JavaScript (Frontend)

```javascript
import { io } from 'socket.io-client';

const socket = io('http://localhost:5000');

// Conectar
socket.on('connect', () => {
  console.log('Conectado!');
});

// Receber ID do usuário
socket.on('user_connected', (data) => {
  console.log('Meu ID:', data.user_id);
});

// Encontrar estranho
socket.emit('find_stranger');

// Receber match
socket.on('match_found', (data) => {
  console.log('Match encontrado!', data.room_id);
});

// Enviar mensagem
socket.emit('send_message', { message: 'Olá!' });

// Receber mensagem
socket.on('new_message', (data) => {
  console.log('Nova mensagem:', data.message);
});
```

### Python (Cliente de teste)

```python
import socketio

sio = socketio.Client()

@sio.event
def connect():
    print('Conectado ao servidor')

@sio.event
def user_connected(data):
    print(f'ID do usuário: {data["user_id"]}')

@sio.event
def match_found(data):
    print(f'Match encontrado! Sala: {data["room_id"]}')

@sio.event
def new_message(data):
    print(f'Mensagem: {data["message"]}')

# Conectar
sio.connect('http://localhost:5000')

# Encontrar estranho
sio.emit('find_stranger')

# Enviar mensagem
sio.emit('send_message', {'message': 'Olá do Python!'})
```

## Monitoramento

### Métricas Disponíveis

- Número de usuários conectados
- Número de usuários aguardando
- Número de salas ativas
- Tempo médio de espera para match
- Duração média das conversas

### Logs

O servidor registra os seguintes eventos:
- Conexões e desconexões de usuários
- Matches realizados
- Mensagens enviadas (sem conteúdo)
- Erros de WebSocket
- Tentativas de WebRTC

### Health Check

```bash
curl http://localhost:5000/api/status
```

Resposta esperada para servidor saudável:
```json
{
  "status": "online",
  "connected_users": 0,
  "waiting_users": 0,
  "active_rooms": 0
}
```

